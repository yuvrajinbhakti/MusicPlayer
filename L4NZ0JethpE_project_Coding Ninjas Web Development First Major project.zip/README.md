# CodingNinja-Music-Player-Project
In my B.tech first year we had this Coding Ninja Course for Web Tech. and In the course I had a Major project to make Homepage and single playlist page for a Online Music PLayer website like Spotify but onlie Using only HTML and CSS (can latter use JS on it).


Main Homepage of the website is index.html and styling for the this html is done by external css called stylesheet.css and for the Playlist page html is Single Playlist Screen.html and styling css is Single Playlist Screen Style.css and there are two more css files those for to make the pages more responsive and I don't think that you need to touch those and all the media(images) required for these pages are in the "media.zip" you need to extract this file.